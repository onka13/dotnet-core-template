﻿namespace $safeprojectname$.Repositories
{
    public partial class BookEfRepository
    {
    }
}