﻿namespace $safeprojectname$.Repositories
{
    public partial class BookMongoRepository
    {
    }
}