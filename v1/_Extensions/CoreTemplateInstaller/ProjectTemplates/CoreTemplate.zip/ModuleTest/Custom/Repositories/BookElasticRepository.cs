﻿namespace $safeprojectname$.Repositories
{
    public partial class BookElasticRepository
    {
    }
}