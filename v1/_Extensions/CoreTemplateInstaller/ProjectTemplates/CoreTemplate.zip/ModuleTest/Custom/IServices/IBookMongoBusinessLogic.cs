﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using CoreCommon.Business.Service.Base;
using CoreCommon.Data.Domain.Business;
using CoreCommon.Data.Domain.Entitites;
using CoreCommon.Data.Domain.Enums;
using $safeprojectname$.Generated.Entities;
using $safeprojectname$.Generated.Enums;

namespace $safeprojectname$.IServices
{
    public partial interface IBookMongoBusinessLogic
    {
        ServiceResult<string> Sample1(string message);
	}
}     
