﻿namespace $safeprojectname$.IRepositories
{
    public partial interface IBookMongoRepository
    {
	}
}    
