﻿namespace $safeprojectname$.IRepositories
{
    public partial interface IBookElasticRepository
    {
	}
}    
