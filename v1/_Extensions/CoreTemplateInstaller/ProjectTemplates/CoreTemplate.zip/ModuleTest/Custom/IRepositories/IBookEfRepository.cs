﻿namespace $safeprojectname$.IRepositories
{
    public partial interface IBookEfRepository
    {
	}
}    
