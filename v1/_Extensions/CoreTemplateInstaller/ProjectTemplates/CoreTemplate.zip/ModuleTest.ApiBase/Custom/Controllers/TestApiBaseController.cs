﻿
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Generated.Controllers
{
    public class TestApiBaseController : Controller
    {
        
    }
}
