﻿using CoreCommon.Data.Domain.Business;

namespace $safeprojectname$.Models
{
    /// <summary>
    /// Service result codes for Common Module
    /// </summary>
    public class ResponseCodes : ServiceResultCode
    {
    }
}
