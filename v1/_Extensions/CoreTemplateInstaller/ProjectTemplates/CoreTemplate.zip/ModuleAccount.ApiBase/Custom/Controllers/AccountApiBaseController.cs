﻿
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Generated.Controllers
{
    public class AccountApiBaseController : Controller
    {
        
    }
}
