﻿using ModuleCommon.ApiBase.Components;

namespace $safeprojectname$.Components
{
    /// <summary>
    /// Base controller for anonymous users
    /// </summary>
    public abstract class PublicBaseController : BaseController
    {
    }
}
