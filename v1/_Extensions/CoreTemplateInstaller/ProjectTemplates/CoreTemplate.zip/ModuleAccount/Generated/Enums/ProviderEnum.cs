﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum ProviderEnum : byte
    {

        [Description("")]
        None = 1, 
        [Description("")]
        Facebook = 2, 
        [Description("")]
        Google = 3, 
    }
}
