﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum DummyEnum : int
    {

    }
}
