﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Components
{
    /// <summary>
    /// Account helper methods
    /// </summary>
    public class AccountHelper
    {
    }
}
