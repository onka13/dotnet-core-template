﻿namespace $safeprojectname$.Models
{
    public class AdminTokenData
    {
        public int UserId { get; set; }
        public bool IsSuper { get; set; }
    }
}
