﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Models
{
    public class TemplateConfig
    {
        public int SomeSetting { get; set; }
    }
}
