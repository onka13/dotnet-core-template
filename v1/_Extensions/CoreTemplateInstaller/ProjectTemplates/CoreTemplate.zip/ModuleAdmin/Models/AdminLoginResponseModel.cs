﻿using $safeprojectname$.Generated.Entities;
using $safeprojectname$.Generated.Enums;
using System.Collections.Generic;

namespace $safeprojectname$.Models
{
    public class AdminLoginResponseModel
    {
        public string Name { get; set; }
        public int UserId { get; set; }
        public bool IsSuper { get; set; }
        public AdminUserTheme Theme { get; set; }
        public string Token { get; set; }
        public List<AdminRoleDefinitionEntity> Roles { get; set; }
    }
}
