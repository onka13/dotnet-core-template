﻿namespace $safeprojectname$.Models
{
    public class ServiceResultCodeAdmin
    {
        public const int LoginUser = 100;
        public const int RefreshToken = 101;
        public const int DuplicateEmail = 102;
        public const int UserInvalidCredential = 103;
    }
}
