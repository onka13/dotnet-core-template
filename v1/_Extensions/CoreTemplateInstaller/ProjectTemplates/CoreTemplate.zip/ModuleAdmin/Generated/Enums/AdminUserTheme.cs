﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum AdminUserTheme : byte
    {

        [Description("")]
        Light = 1, 
        [Description("")]
        Dark = 2, 
    }
}
