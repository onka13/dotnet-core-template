﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum ErpMainRoleAction : byte
    {

        [Description("")]
        Allow = 1, 
        [Description("")]
        Block = 2, 
    }
}
