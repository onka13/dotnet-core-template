﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum ErpCustomerPurchaseType : byte
    {

        [Description("Konsinye")]
        Consignee = 1, 
        [Description("Satın Alma")]
        Purchasing = 2, 
    }
}
