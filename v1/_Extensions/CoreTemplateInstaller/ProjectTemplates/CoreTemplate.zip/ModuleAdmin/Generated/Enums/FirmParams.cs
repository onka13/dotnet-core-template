﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum FirmParams : int
    {

        [Description("")]
        FinLocalCurrency = 1, 
    }
}
