﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum AdminRoleAction : byte
    {

        [Description("")]
        Allow = 1, 
        [Description("")]
        Block = 2, 
    }
}
