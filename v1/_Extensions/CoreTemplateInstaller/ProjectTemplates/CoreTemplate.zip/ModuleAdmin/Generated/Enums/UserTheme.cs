﻿
using System.ComponentModel;

namespace $safeprojectname$.Generated.Enums
{
    public enum UserTheme : byte
    {

        [Description("")]
        Light = 1, 
        [Description("")]
        Dark = 2, 
    }
}
