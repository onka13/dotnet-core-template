﻿
using System;
using System.Collections.Generic;
using System.Linq;
using CoreCommon.Data.Domain.Entitites;
using CoreCommon.Data.Domain.Enums;
using CoreCommon.Data.EntityFrameworkBase.Base;
using CoreCommon.Data.ElasticSearch.Base;
using CoreCommon.Data.Domain.Business;
using $safeprojectname$.Generated.Entities;
using $safeprojectname$.Generated.Enums;

namespace $safeprojectname$.IRepositories
{
    public partial interface IAdminRoleActionListRepository
    {
	}
}    
