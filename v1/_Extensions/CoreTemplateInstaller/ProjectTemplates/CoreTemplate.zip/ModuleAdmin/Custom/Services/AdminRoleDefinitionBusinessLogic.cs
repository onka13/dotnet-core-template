﻿
using System.Collections.Generic;
using $safeprojectname$.Generated.Entities;
using $safeprojectname$.Generated.Enums;
using $safeprojectname$.Repositories;

using CoreCommon.Business.Service.Base;
using CoreCommon.Data.Domain.Business;
using CoreCommon.Data.Domain.Entitites;
using CoreCommon.Data.Domain.Enums;

namespace $safeprojectname$.Services
{
    public partial class AdminRoleDefinitionBusinessLogic
    {
        public ServiceResult<string> Sample1(string message)
        {
            var response = ServiceResult<string>.Instance.ErrorResult(ServiceResultCode.Error);
            response.SuccessResult("Message: " + message);
            return response;
        }            
    }
}
