﻿using System.Collections.Generic;
using $safeprojectname$.Generated.Entities;
using CoreCommon.Data.Domain.Business;
using $safeprojectname$.IServices;
using System.Linq;

namespace $safeprojectname$.Services
{
    public partial class AdminUserRoleMapBusinessLogic
    {
        public IAdminRoleBusinessLogic RoleBusinessLogic { get; set; }

        public ServiceResult<object> SaveUserRoles(int userId, List<int> roleIds)
        {
            var response = ServiceResult<object>.Instance.ErrorResult(ServiceResultCode.Error);
            
            if (roleIds == null) roleIds = new List<int>();

            var currentRoles = ListByUserId(userId).Value;
            var roles = RoleBusinessLogic.FindBy(x => roleIds.Contains(x.Id)).Value;

            var newRoles = new List<AdminUserRoleMapEntity>();
            var existsIds = new List<int>();

            foreach (var role in roles)
            {
                var entity = new AdminUserRoleMapEntity
                {
                    RoleId = role.Id,
                    UserId = userId
                };
                var exist = currentRoles.FirstOrDefault(x => x.RoleId == role.Id);
                if (exist == null)
                {
                    newRoles.Add(entity);
                }
                else
                {
                    existsIds.Add(exist.Id);
                }
            }

            var deletedRoles = currentRoles.Where(x => !existsIds.Any(y => y == x.Id)).ToList();

            response = response.SuccessResult(new
            {
                insert = BulkInsert(newRoles).Value,
                delete = BulkDelete(deletedRoles).Value
            });
            response.Code = ServiceResultCode.Updated;
            return response;
        }

        public ServiceResult<object> ListUserRoles(int userId)
        {
            var response = ServiceResult<object>.Instance.ErrorResult(ServiceResultCode.Error);

            var currentRoles = FindAndIncludeBy(x => x.UserId == userId, x => x.Role).Value.Select(x => (new
            {
                key = x.RoleId,
                label =  x.Role.Name
            }));

            return response.SuccessResult(currentRoles);
        }
    }
}
