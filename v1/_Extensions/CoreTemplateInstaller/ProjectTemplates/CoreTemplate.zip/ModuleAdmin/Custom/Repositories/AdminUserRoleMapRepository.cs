﻿
using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Generated.Entities;
using $safeprojectname$.IRepositories;
using $safeprojectname$.Generated.Enums;

using CoreCommon.Data.Domain.Entitites;
using CoreCommon.Data.Domain.Enums;
using CoreCommon.Data.EntityFrameworkBase.Base;
using CoreCommon.Data.ElasticSearch.Base;
using CoreCommon.Data.Domain.Business;

namespace $safeprojectname$.Repositories
{
    public partial class AdminUserRoleMapRepository
    {
    }
}