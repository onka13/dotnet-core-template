﻿using System.Collections.Generic;
using CoreCommon.Data.Domain.Business;

namespace $safeprojectname$.IServices
{
    public partial interface IAdminUserRoleMapBusinessLogic
    {
        ServiceResult<object> SaveUserRoles(int userId, List<int> roleIds);
        ServiceResult<object> ListUserRoles(int userId);
    }
}     
