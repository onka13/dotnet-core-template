﻿using $safeprojectname$.Generated.Entities;
using CoreCommon.Data.Domain.Business;
using $safeprojectname$.Models;

namespace $safeprojectname$.IServices
{
    public partial interface IAdminUserBusinessLogic
    {
        ServiceResult<int> Upsert(AdminUserEntity model);
        ServiceResult<AdminLoginResponseModel> Login(string email, string password);
    }
}     
